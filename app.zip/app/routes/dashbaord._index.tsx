export default function DashboardIndexPage() {
    return <div>
        
    </div>
}