import { Card, Button, TextInput, Checkbox } from "flowbite-react";
import {FaCertificate} from "react-icons/fa"
import { Link } from "@remix-run/react";

export default function InvestmentOrder(){
    return <div className="text-white grid grid-cols-1">
                <h1 className="text-5xl mb-5 justify-self-center">Ready to Invest?</h1>
                <div className="flex ... gap-6">
                    <div className="w-2/3 ...">
                        <Card className="mb-3" >
                            <div className="grid grid-cols-6">
                                <FaCertificate className="text-5xl"/>
                                <div className="col-span-5">
                                    <p className="text-xl">STARTER</p>
                                    <p className="text-xs">Invest for 14 days and get daily profit of 120%</p>
                                </div>
                            </div>
                            
                        </Card>

                        <p className="text-sm">Enter Your Amount</p>
                        <TextInput className="mb-2"></TextInput>
                        <p className="text-xs mb-2">Note: Minimum invest 1000 USD and up to 4999 USD</p>

                        <p className="italic text-sm">Payment Method</p>
                        <Card className="mb-2">
                            <div className="grid grid-cols-6">
                                <div></div>
                                <div className="col-span-5">
                                    <p>Account Balance</p>
                                    <p className="text-xs">Current balance: $ 0.00</p>
                                </div>
                                
                            </div>
                            
                        </Card> 
                        <div className="flex ...">
                            <Checkbox className="mr-3"/><p>I agree to the <Link to="/terms" className="text-blue-500">terms and conditions</Link></p>
                        </div>
                        
                    </div>
                    <div className="w-1/3">
                        <Card>
                            <p>Your Investment details</p>
                            <div className="grid grid-cols-2">
                                <div className="grid grid-rows-2 text-sm">
                                    <p >Name of scheme</p>
                                    <p>STARTER</p>
                                </div>
                                <div className="grid grid-rows-2 text-sm">
                                    <p >Term of the scheme</p>
                                    <p>14 Days</p>
                                </div>
                            </div>
                            <div className="grid grid-cols-2">
                                <div className="grid grid-rows-2 text-sm">
                                    <p>Daily profit %</p>
                                    <p>130%</p>
                                </div>
                                <div className="grid grid-rows-2 text-sm">
                                    <p>Term starts at</p>
                                    <p>Today 6/10/2023 6:41:41 PM</p>
                                    
                                </div>     
                            </div>
                            <hr></hr>
                            <div className="grid grid-cols-2 text-sm">
                                <p>Term end at</p>
                                <p>6/24/2023 6:41:41 PM</p>
                            </div>
                            <hr></hr>
                            <div className="grid grid-cols-2 text-sm">
                                <p>Amount to invest</p>
                                <p>$ 0.00</p>
                            </div>
                            <hr></hr>
                            <div className="grid grid-cols-2 text-sm">
                                <p>Total Charge</p>
                                <p>$ 0.00</p>
                            </div>
                            <Button>Confirm & proceed</Button>
                        </Card>
                    </div>
                </div>
                
            </div>
}